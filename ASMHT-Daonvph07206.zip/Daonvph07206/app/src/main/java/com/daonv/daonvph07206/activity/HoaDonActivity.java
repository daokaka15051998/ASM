package com.daonv.daonvph07206.activity;

import android.os.Bundle;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.daonv.daonvph07206.R;

import java.util.Calendar;


public class HoaDonActivity extends AppCompatActivity {


    EditText edtNgayMua;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hoa_don);

        Calendar cal = Calendar.getInstance();
//        String year = cal.get(Calendar)


        edtNgayMua = findViewById(R.id.edtNgayMua);






    }
}
