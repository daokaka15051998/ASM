package com.daonv.daonvph07206.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.daonv.daonvph07206.R;
import com.daonv.daonvph07206.dao.SachDAO;
import com.daonv.daonvph07206.dao.TheLoaiDAO;
import com.daonv.daonvph07206.model.Sach;

import java.util.ArrayList;
import java.util.List;


public class SachActivity extends AppCompatActivity {

    EditText edtMaSach, edtTenSach, edtTacGia, edtNXB, edtGiaBan, edtSoLuong;
    Button btnThemSach, btnHuySach, btnShowSach;
    ImageView imgAddTheLoail;
    Spinner spnLoaiSach;
    String tenLoaiSach = "";
    SachDAO sachDAO;
    List<String> tenLoai;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sach);


        edtMaSach = findViewById(R.id.edtMaSach);
        edtTenSach = findViewById(R.id.edtTenSach);
        edtTacGia = findViewById(R.id.edtTacGia);
        edtNXB = findViewById(R.id.edtNXB);
        edtGiaBan = findViewById(R.id.edtGiaBan);
        edtSoLuong = findViewById(R.id.edtSoLuong);
        btnThemSach = findViewById(R.id.btnSach);
        btnHuySach = findViewById(R.id.btnHuySach);
        btnShowSach = findViewById(R.id.btnShowSach);
        imgAddTheLoail = findViewById(R.id.imgTheLoai);
        spnLoaiSach = findViewById(R.id.spnUpLoaiSach);

        //Hiển thị spinner
        tenLoai = new ArrayList<>();
        TheLoaiDAO theLoaiDAO = new TheLoaiDAO(SachActivity.this);
        tenLoai = theLoaiDAO.getTheLoai();
        ArrayAdapter<String> spAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, tenLoai);
        spAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnLoaiSach.setAdapter(spAdapter);


        btnShowSach.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getBaseContext(), ListSachActivity.class));
            }
        });

        imgAddTheLoail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getBaseContext(), TheLoaiActivity.class));
            }
        });

        spnLoaiSach.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                tenLoaiSach = tenLoai.get(spnLoaiSach.getSelectedItemPosition());
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }

    public void addSach(View view) {
        String iDSach = edtMaSach.getText().toString().trim();
        String iDLoaiSach = tenLoaiSach;
        String tenSach = edtTenSach.getText().toString();
        String tacGia = edtTacGia.getText().toString();
        String nxb = edtNXB.getText().toString();
        float giaBan = Float.parseFloat(edtGiaBan.getText().toString());
        int soLuong = Integer.parseInt(edtSoLuong.getText().toString());

        sachDAO = new SachDAO(SachActivity.this);
        Sach sach = new Sach(iDSach, iDLoaiSach, tenSach, tacGia, nxb, giaBan, soLuong);
        long result = sachDAO.insertSach(sach);

        if (result > 0){
            Toast.makeText(SachActivity.this, "Thêm sách thành công", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(SachActivity.this, "Thêm sách thất bại", Toast.LENGTH_SHORT).show();
        }
    }

    public void clearSach(View view) {
        edtMaSach.setText("");
        edtTenSach.setText("");
        edtTacGia.setText("");
        edtNXB.setText("");
        edtGiaBan.setText("");
        edtSoLuong.setText("");
    }

}
