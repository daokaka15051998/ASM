package com.daonv.daonvph07206.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.daonv.daonvph07206.R;
import com.daonv.daonvph07206.adapter.TheLoaiAdapter;
import com.daonv.daonvph07206.dao.TheLoaiDAO;
import com.daonv.daonvph07206.model.TheLoai;

import java.util.List;


public class ListTheLoaiActivity extends AppCompatActivity {

    ListView lvTheLoai;
    TheLoaiDAO theLoaiDAO;
    TheLoaiAdapter theLoaiAdapter;
    List<TheLoai> theLoaiList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_the_loai);
        setTitle("Thế loại");


        lvTheLoai = findViewById(R.id.lvTheLoai);
        theLoaiDAO = new TheLoaiDAO(this);
        theLoaiList = theLoaiDAO.getAllTheLoai();

        theLoaiAdapter = new TheLoaiAdapter(theLoaiList, ListTheLoaiActivity.this);
        lvTheLoai.setAdapter(theLoaiAdapter);

        lvTheLoai.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Context context = view.getContext();
                Intent intent = new Intent(context, UpdateTheLoaiActivity.class);

                Bundle bundle = new Bundle();
                bundle.putString("maLoai_key", String.valueOf(theLoaiList.get(position).getMaTheLoai()));
                bundle.putString("tenLoai_key", theLoaiList.get(position).getTenTheLoai());
                bundle.putString("viTri_key", theLoaiList.get(position).getViTri());
                bundle.putString("mota_key", theLoaiList.get(position).getMoTa());
                intent.putExtra("bundleTL", bundle);
                startActivity(intent);
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.mnAddTheLoai:
                startActivity(new Intent(getBaseContext(), TheLoaiActivity.class));
                break;

        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu_list_the_loai, menu);

        return super.onCreateOptionsMenu(menu);
    }
}
