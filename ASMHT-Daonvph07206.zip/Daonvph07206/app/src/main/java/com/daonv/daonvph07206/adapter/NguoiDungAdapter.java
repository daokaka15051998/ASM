package com.daonv.daonvph07206.adapter;

import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.daonv.daonvph07206.R;
import com.daonv.daonvph07206.dao.NguoiDungDAO;
import com.daonv.daonvph07206.model.NguoiDung;

import java.util.List;


public class NguoiDungAdapter extends BaseAdapter {

    List<NguoiDung> nguoiDungList;
    NguoiDungDAO nguoiDungDAO;
    Context context;
//    NguoiDung nguoiDung;

    public NguoiDungAdapter(List<NguoiDung> nguoiDungList, Context context) {
        this.nguoiDungList = nguoiDungList;
        this.context = context;
    }

    @Override
    public int getCount() {
        return nguoiDungList.size();
    }

    @Override
    public Object getItem(int i) {
        return nguoiDungList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    private AlertDialog alertDialog;

    @Override
    public View getView(final int i, View view, ViewGroup viewGroup) {

        LayoutInflater inflater = LayoutInflater.from(viewGroup.getContext());
        view = inflater.inflate(R.layout.item_nguoidung_list, viewGroup, false);
        TextView tvName = view.findViewById(R.id.tvName);
        TextView tvPhone = view.findViewById(R.id.tvPhone);
        ImageView imgUser = view.findViewById(R.id.imgUser);
        ImageView imgDeleteUser = view.findViewById(R.id.imgDeleteUser);

        final NguoiDung nguoiDung =nguoiDungList.get(i);

        tvName.setText(nguoiDung.getUsername());
        tvPhone.setText(nguoiDung.getPhone());

        imgDeleteUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                final View dialog = LayoutInflater.from(context).inflate(R.layout.dialog_delete, null);
                builder.setView(dialog);

                Button btnYes = dialog.findViewById(R.id.btnYes);
                Button btnNo = dialog.findViewById(R.id.btnNo);

                btnYes.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        nguoiDungDAO = new NguoiDungDAO(context);
                        long result = nguoiDungDAO.deleteUser(nguoiDungList.get(i).getUsername());
                        if (result > 0) {
                            Toast.makeText(context, "Xóa thành công", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(context, "Xóa thất bại", Toast.LENGTH_SHORT).show();
                        }
                        nguoiDungList.remove(nguoiDung);
                        notifyDataSetChanged();
                        alertDialog.dismiss();
                    }
                });

                btnNo.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        alertDialog.dismiss();
                    }
                });
                builder.create();
                alertDialog = builder.show();
            }
        });
        return view;
    }
}
