package com.daonv.daonvph07206.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.daonv.daonvph07206.dao.NguoiDungDAO;
import com.daonv.daonvph07206.dao.SachDAO;
import com.daonv.daonvph07206.dao.TheLoaiDAO;

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "dbBookManager";
    public static final int VERSION = 1;
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        sqLiteDatabase.execSQL(NguoiDungDAO.SQL_NguoiDung);
        sqLiteDatabase.execSQL(TheLoaiDAO.SQL_TheLoai);
        sqLiteDatabase.execSQL(SachDAO.SQL_Sach);

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + NguoiDungDAO.TABLE_NAME);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TheLoaiDAO.TABLE_NAME);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + SachDAO.TABLE_NAME);

    }
}
