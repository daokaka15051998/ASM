package com.daonv.daonvph07206.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import com.daonv.daonvph07206.R;
import com.daonv.daonvph07206.adapter.SachAdapter;
import com.daonv.daonvph07206.dao.SachDAO;
import com.daonv.daonvph07206.model.Sach;

import java.util.ArrayList;
import java.util.List;


public class ListSachActivity extends AppCompatActivity {

    ListView lvBook;
    EditText edtSearch;
    Button btnSearch;

    List<Sach> sachList = new ArrayList<>();
    SachDAO sachDAO;
    SachAdapter sachAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_sach);

        edtSearch = findViewById(R.id.edtSearch);
        btnSearch = findViewById(R.id.btnSearch);

        lvBook = findViewById(R.id.lvSach);

        sachDAO = new SachDAO(ListSachActivity.this);
        sachList = sachDAO.getAllSach();
        sachAdapter = new SachAdapter(sachList, ListSachActivity.this);

        lvBook.setAdapter(sachAdapter);

        lvBook.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(ListSachActivity.this, UpdateSachActivity.class);
                Bundle bundle = new Bundle();
                bundle.putString("maSach_key", sachList.get(i).getMaSach());
                bundle.putString("tenSach_key", sachList.get(i).getTenSach());
                bundle.putString("tacGia_key", sachList.get(i).getTacGia());
                bundle.putString("nxb_key", sachList.get(i).getNxb());
                bundle.putString("giaBan_key", String.valueOf(sachList.get(i).getGiaBan()));
                bundle.putString("soLuong_key", String.valueOf(sachList.get(i).getSoLuong()));
                intent.putExtra("bundleSach", bundle);
                startActivity(intent);
            }
        });
    }
}
