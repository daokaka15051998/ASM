package com.daonv.daonvph07206.adapter;

import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.daonv.daonvph07206.R;
import com.daonv.daonvph07206.dao.SachDAO;
import com.daonv.daonvph07206.model.Sach;

import java.util.List;


public class SachAdapter extends BaseAdapter {

    List<Sach> sachList;
    SachDAO sachDAO;
    Context context;

    public SachAdapter(List<Sach> sachList, Context context) {
        this.sachList = sachList;
        this.context = context;
    }

    @Override
    public int getCount() {
        return sachList.size();
    }

    @Override
    public Object getItem(int i) {
        return sachList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    private AlertDialog alertDialog;

    @Override
    public View getView(final int i, View view, ViewGroup viewGroup) {
        LayoutInflater inflater = LayoutInflater.from(viewGroup.getContext());
        view = inflater.inflate(R.layout.item_book, viewGroup, false);

        TextView tvIdSach = view.findViewById(R.id.tvIdSach);
        TextView tvSoLuong = view.findViewById(R.id.tvSoLuong);
        TextView tvTenSach = view.findViewById(R.id.tvTenSach);

        ImageView imgDelBook = view.findViewById(R.id.imgDelBook);

        final Sach sach = sachList.get(i);

        tvIdSach.setText(sach.maSach);
        tvTenSach.setText(sach.tenSach);
        tvSoLuong.setText(String.valueOf(sach.getSoLuong()));

        imgDelBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                final View dialog = LayoutInflater.from(context).inflate(R.layout.dialog_delete, null);
                builder.setView(dialog);

                Button btnYes = dialog.findViewById(R.id.btnYes);
                Button btnNo = dialog.findViewById(R.id.btnNo);

                btnYes.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        sachDAO = new SachDAO(context);
                        long result = sachDAO.deleteSach(sachList.get(i).getMaSach());
                        if (result > 0) {
                            Toast.makeText(context, "Xóa thành công", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(context, "Xóa thất bại", Toast.LENGTH_SHORT).show();
                        }
                        sachList.remove(sach);
                        notifyDataSetChanged();
                        alertDialog.dismiss();
                    }
                });

                btnNo.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        alertDialog.dismiss();
                    }
                });
                builder.create();
                alertDialog = builder.show();
            }
        });

        return view;
    }


}
