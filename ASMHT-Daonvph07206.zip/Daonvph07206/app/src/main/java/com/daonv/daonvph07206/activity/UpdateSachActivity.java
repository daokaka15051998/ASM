package com.daonv.daonvph07206.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.daonv.daonvph07206.R;
import com.daonv.daonvph07206.dao.SachDAO;
import com.daonv.daonvph07206.dao.TheLoaiDAO;
import com.daonv.daonvph07206.model.Sach;

import java.util.ArrayList;
import java.util.List;

public class UpdateSachActivity extends AppCompatActivity {

    EditText edtUpMaSach, edtUpTenSach, edtUpTacGia, edtUpNXB, edtUpGiaBan, edtUpSoLuong;
    Button btnUpSach, btnHuyUpSach, btnShowUpSach;
    ImageView imgUpTheLoai;
    Spinner spnUpLoaiSach;
    String tenLoaiSach = "";
    SachDAO sachDAO;
    List<String> tenLoai;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_sach);

        edtUpMaSach = findViewById(R.id.edtUpMaSach);
        edtUpTenSach = findViewById(R.id.edtUpTieuDe);
        edtUpTacGia = findViewById(R.id.edtUpTacGia);
        edtUpNXB = findViewById(R.id.edtNXB);
        edtUpGiaBan = findViewById(R.id.edtUpGia);
        edtUpSoLuong = findViewById(R.id.edtUpSoLuong);
        btnUpSach = findViewById(R.id.btnUpSach);
        btnHuyUpSach = findViewById(R.id.btnHuyUpSach);
        btnShowUpSach = findViewById(R.id.btnShowUpSach);
        imgUpTheLoai = findViewById(R.id.imgTheLoai);
        spnUpLoaiSach = findViewById(R.id.spnUpLoaiSach);

        //Hiển thị spinner
        tenLoai = new ArrayList<>();
        TheLoaiDAO theLoaiDAO = new TheLoaiDAO(UpdateSachActivity.this);
        tenLoai = theLoaiDAO.getTheLoai();
        ArrayAdapter<String> spAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, tenLoai);
        spAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnUpLoaiSach.setAdapter(spAdapter);


        Intent intent = getIntent();
        Bundle bundle = intent.getBundleExtra("bundleSach");
        if (bundle != null) {
            edtUpMaSach.setText(bundle.getString("maSach_key"));
            edtUpTenSach.setText(bundle.getString("tenSach_key"));
            edtUpTacGia.setText(bundle.getString("tacGia_key"));
            edtUpNXB.setText(bundle.getString("nxb_key"));
            edtUpGiaBan.setText(bundle.getString("giaBan_key"));
            edtUpSoLuong.setText(bundle.getString("soLuong_key"));
        }
        spnUpLoaiSach.setAdapter(spAdapter);

        spnUpLoaiSach.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                tenLoaiSach = tenLoai.get(spnUpLoaiSach.getSelectedItemPosition());
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        btnUpSach.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String maSach = edtUpMaSach.getText().toString();
                String tenLoai = tenLoaiSach;
                String tenSach = edtUpTenSach.getText().toString();
                String tacGia = edtUpTacGia.getText().toString();
                String nxb = edtUpNXB.getText().toString();
                float giaBan = Float.parseFloat(edtUpGiaBan.getText().toString());
                int soLuong = Integer.parseInt(edtUpSoLuong.getText().toString());

                sachDAO = new SachDAO(UpdateSachActivity.this);
                Sach sach = new Sach(maSach, tenLoai, tenSach, tacGia, nxb, giaBan, soLuong);
                long result = sachDAO.updateSach(sach);
                if (result > 0){
                    Toast.makeText(UpdateSachActivity.this, "Sửa thành công", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(UpdateSachActivity.this, "Sửa thất bại", Toast.LENGTH_SHORT).show();

                }
            }
        });
    }

    public void clearUpSach(View view) {
        startActivity(new Intent(getBaseContext(), ListSachActivity.class));
    }

    public void showUpSach(View view) {
        startActivity(new Intent(getBaseContext(), ListSachActivity.class));

    }
}
