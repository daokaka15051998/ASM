package com.daonv.daonvph07206.activity;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.daonv.daonvph07206.R;

public class HDCTActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hdct);
    }
}
